apt update -y
apt -o Dpkg::Options::="--force-confold" upgrade -y
